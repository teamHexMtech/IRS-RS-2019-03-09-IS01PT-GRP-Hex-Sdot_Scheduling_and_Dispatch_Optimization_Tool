package com.iss.rs.mapper;

import com.iss.rs.entity.Lot;

import java.util.List;

public interface LotMapper {
    List<Lot> getAllLot();
}
