package com.iss.rs.mapper;

import com.iss.rs.entity.Oven;

import java.util.List;

public interface OvenMapper {
    List<Oven> getAllOven();
}
